clc;
clear all;
h=0.25;
y1=1;
x1=1;
x0 = x1-(h/2)
x2=x1+(h/2)
yo = x0 /2
f1 = h*(2*y0-x0)

y1 = y0+f1/2

f1= 2*y1 -2*yo




