clc;
clear all;

t = [ 0 0.25 0.5 0.75 1 1.25 1.5];
x = [ 0 4.3 10.2 17.2 26.2 33.1 39.1];

v(1) = five1(x,1);
v(2) = three2(x,2);
v(3) = five2(x,3);
v(4) = five2(x,4);
v(5) = five2(x,5);
v(6) = three2(x,6);
v(7) = five1(x,7);
disp("Hiz: ");
for i=1:6
    disp("t=" + t(i) + " : Hiz=" + v(i));
end
disp("Ileri Sonlu Fark Formulleriyle Ivme: ");
for i=1:6
    disp("t=" + t(i) + " : Ivme=" + isf(v,i));
end
disp("Geri Sonlu Fark Formulleriyle Ivme: ");
for i=7:-1:2
    disp("t=" + t(i) + " : Ivme=" + gsf(v,i));
end
disp("Merkezi Sonlu Fark Formulleriyle Ivme: ");
for i=2:6
    disp("t=" + t(i) + " : Ivme=" + msf(v,i));
end

function y = msf(x,i)
    h = 0.25;
    y = (x(i+1)-x(i-1))/(2*h);
end

function y = isf(x,i)
    h = 0.25;
    y = (x(i+1)-x(i))/h;
end


function y = gsf(x,i)
    h = 0.25;
    y = (x(i)-x(i-1))/h;
end

function y = five1(x,i)
    if i==7
        h = -0.25;
        y = (1/(12*h))*(-25*x(i)+48*x(i-1)-36*x(i-2)+16*x(i-3)-3*x(i-4));
    else
        h = 0.25;
        y = (1/(12*h))*(-25*x(i)+48*x(i+1)-36*x(i+2)+16*x(i+3)-3*x(i+4)); 
    end
end


function y = three2(x,i)
    h = 0.25;
    y = (1/(2*h))*(x(i+1)-x(i-1));
end

function y = five2(x,i)
    h = 0.25;
    y = (1/(12*h))*(x(i-2)-8*x(i-1)+8*x(i+1)-x(i+2));
end

