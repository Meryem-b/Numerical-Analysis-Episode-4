clc;
clear all;
f = @(x,y) x+y ;
ay = -1;
by=1;
ax=-2; 
bx=2;
ny=16;
nx=14;
hy=(by-ay)/ny;
hx =(bx-ax)/nx;
s=0;
for i = 0 :ny % loop of the outer integral
    if i == 0 || i == ny
        p=1;
    elseif mod(i,2) ~= 0
        p=4;
    else
        p=2;
    end
    
for j= 0 : nx  %loop of the inner integral
    if j == 0 || j == nx
        q=1;
    elseif mod(j,2) ~= 0
        q=4;
    else
        q=2;
    end
    x=ax +j*hx;
    y=ay + i*hy;
    s=s+ p*q*f(x,y);
end
end
I= hx*hy/9*s
    