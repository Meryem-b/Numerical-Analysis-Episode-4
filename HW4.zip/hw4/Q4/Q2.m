%SOLVE Euler's method
%dy/dx=4*exp(-x)-3*y


h=0.1; % step's size
x=0:h:2; %solve from x=[0,2]
y=zeros(size(x));
y(1)=1;
n=numel(y);

for i = 1:n-1
     dydx= - 4*exp(-x(i))-3*y(i);
    y(i+1)= y(i)+  dydx*h;
     fprintf('="Y"\n\t   %0.01f',y(i));
end

plot(x,y);
grid on;



