% f=@(x,y) 4*exp(-x)-3*y;
% It calculates ODE using Runge-Kutta 4th order method
clc;                            
clear; 
h=0.1;   % step size
x=0:h:2; %solve from x=[0,2]
                                       
Y = zeros(1,length(x)); 
y(1) = 1;  % initial condition
F = @(x,y) 4*exp(-x)-3*y;                    

for i=1:(length(x)-1)      % calculation loop
    k1 = F(x(i),y(i));
    k2 = F(x(i)+0.5*h,y(i)+0.5*h*k1);
    k3 = F((x(i)+0.5*h),(y(i)+0.5*h*k2));
    k4 = F((x(i)+h),(y(i)+k3*h));

    y(i+1) = y(i) + (1/6)*(k1+2*k2+2*k3+k4)*h;  % main equation
  
end
display(Y(i+1));

plot(x,y);
grid on;


 
