#include<stdio.h>
#include<stdlib.h>

int main(){
	  double A[]= {16,16.942,17.885,18.827,19.425,4.4894,8.2196,21.763,5.1045,14.137,23.17,6.5116,20.055,23.785,8.8496};
 double X[]={2,2.3142,2.6283,2.9425,3.1416,3.4558,3.7699,4.0841,4.3982,4.7124,5.0265,5.3407,5.6549,5.969,6.2832};
printf("I get directly without dividing the linear part: \n");
 double n,h;
 double c;
 double d=0;
 int i;
 double b=3.1416;
 double a=2;
 double B[8];
 n=4;
 h=(b-a)/n;
 c=(h/2)*(A[0]+2*A[1]+2*A[2]+2*A[3]+A[4]);
 printf("%f\n",c);
 double h2;
 h2=0.3141;
B[0]=(A[4]+4*A[5]+A[6])*(h2/3);
B[1]=(A[6]+4*A[7]+A[8])*(h2/3);
B[2]=(A[8]+4*A[9]+A[10])*(h2/3);
B[3]=(A[10]+4*A[11]+A[12])*(h2/3);
B[4]=(A[12]+4*A[13]+A[14])*(h2/3);
for(i=0;i<5;i++){
	printf("B[%d]=%f\n",i,B[i]);
}
for(i=0;i<5;i++){
 d+=B[i];
}
printf("%f\n",d);
double e;
e=d+c;
printf("%f",e);
}
